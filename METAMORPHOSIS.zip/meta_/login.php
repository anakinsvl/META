<?php

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $mysqli = require __DIR__ . "/database.php";
    
    $sql = sprintf("SELECT * FROM user
                    WHERE email = '%s'",
                   $mysqli->real_escape_string($_POST["email"]));
    
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();
    
    if ($user) {
        
        if (password_verify($_POST["password"], $user["password_hash"])) {
            
            session_start();
            
            session_regenerate_id();
            
            $_SESSION["user_id"] = $user["id"];
            
            header("Location: employee-index.php");
            exit;
        }
    }
    
    $is_invalid = true;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <link href="css/login.css" rel="stylesheet"/>
</head>
<body>
    
    <form method="post">
    <div class="box">
        <div class="form">

            <h1>Log In</h1>
            &nbsp
            <h6>Welcome back! Log in with your credentials.</h6>
            <div class="inputbox">
                <input  type="email" name="email" id="email"
               value="<?= htmlspecialchars($_POST["email"] ?? "") ?>" required="required">
                <span for="email">Email</span>
                <i></i>
            </div>
            
            
            <div class="inputbox">
                <input type="password" name="password" id="password" required="required">
                <span>Password</span>
                <i></i>
            </div>
            <?php if ($is_invalid): ?>
            <em>Invalid login</em>
            <?php endif; ?>
            <div class="links">
                
            <br>
                <a href="signup.html">Signup</a>
            </div>
            <input type="submit" value="Login">
        </div>
    </div>
    </form>
    
</body>
</html>








